// array to hold all our motor definitions with their
// gpio pin and min and max value
var motors = [
    {
        "pin": 17,
        "min": 0.1,
        "max": 0.25,
        "color": "#4a89dc",
        "width": 120,
        "height": 120,
        "dir": 1
    },
    {
        "pin": 27,
        "min": 0.1,
        "max": 0.25,
        "color": "#f6bb42",
        "width": 120,
        "height": 120,
        "dir": 1
    },
    {
        "pin": 22,
        "min": 0.1,
        "max": 0.25,
        "color": "#8cc152",
        "width": 120,
        "height": 120,
        "dir": 1
    },
];

// switches change the direction of the motor.
// define the list of switches and their target motors.
// one switch can change direction of multiple motors
var switches = [
    {
        "pin": 4,
        "target": [27] // target motor on gpio 17 and 22
    },
    {
        "pin": 3,
        "target": [22] // target only motor on gpio 22
    }
]

// this function will loop through our list of motors
// and create control knobs in our GUI
var setupControls = function()
{
    for (var i=0; i<motors.length; i++) {
        // create knob
        $('.motors').append('<input type="text" value="0" class="dial" id="m'+motors[i].pin+'" data-min="0" data-max="100">');
        $('#m'+motors[i].pin).knob({
            width: motors[i].width,
            height: motors[i].height,
            fgColor: motors[i].color,
            release: function(v) {
                var gpio = this.$.attr('id').split("m")[1];
                changeMotorSpeed(gpio, v);
            }    
        });
        
        // create ctrl buttons
        $('.ctrl').append('<div pin="'+motors[i].pin+'"><button cmd="b"><i class="fa fa-backward"></i></button><button cmd="s"><i class="fa fa-stop"></i></button><button cmd="f"><i class="fa fa-forward"></i></button></div>');
    }
    
    drawDirectionIndicators();
    
    // set up button listeners
    $('.ctrl button').click(onButtonClicked);
}

var onButtonClicked = function(e) 
{
    var pin = $(e.currentTarget).parent().attr('pin'),
        cmd = $(e.currentTarget).attr('cmd'),
        val = 0,
        motor = getMotorByPin(pin);
    
    if (cmd == 'f')
        val = motor.max;
    else if (cmd == 'b')
        val = motor.min;
        
    runMotor(pin, val);
}

var drawDirectionIndicators = function()
{
    $('.dir').html("");
    for (var i=0;i<motors.length;i++) {  
        var d = (motors[i].dir == 1) ? 'fa-chevron-right': 'fa-chevron-left';
        $('.dir').append('<div pin="'+motors[i].pin+'"><i class="fa '+d+'"></i></div>');    
    }
}

var changeMotorSpeed = function(pin, value)
{
    var motor = getMotorByPin(pin);
    var val = motor.min + ((motor.max - motor.min)/100 * value);    
    runMotor(pin, val);
}

var runMotor = function(pin, val)
{
    var motor = getMotorByPin(pin);
    
    motor.running = (val === 0) ? false : true;
    // send message to node to move the motor
    Coder.socketConnection.sendData("motor", {
        pin: pin,
        value: val
    });
}

// helper function
var getMotorByPin = function(pin) {
    // find the motor based on gpio
    for (var i=0;i<motors.length;i++) {
        if (motors[i].pin == pin)
            return motors[i];
    }
}
var getSwitchByPin = function(pin) {
    // find the switch based on gpio
    for (var i=0;i<switches.length;i++) {
        if (switches[i].pin == pin)
            return switches[i];
    }
}

var changeDirection = function(d) {
    var s = getSwitchByPin(d.headerNum);
    if (s) {
        for(var i=0;i<s.target.length;i++) {
            var m = getMotorByPin(s.target[i]);
            m.dir = !m.dir;
            // if motor is running, reverse direction
            if (m.running) {
                if (m.dir) {
                    runMotor(m.pin, m.max);        
                } else {
                    runMotor(m.pin, m.min);
                }
            }
        }    
        // update direction indicators    
        drawDirectionIndicators();
    }
}

$(document).ready( function() {

    setupControls();

    // send initial connect message to the server
    Coder.socketConnection.init(function() {
        Coder.socketConnection.sendData( 'connect', {} );    
    });
    
    // set up listener for motor messages
    Coder.socketConnection.addListener("motor", function(data)
    {
        $("#stat").html('<div>Motor: '+data.pin+'</div><div>Value: '+data.val+'</div>');
        console.log(data);
    });
    
    // switch listener.
    // when switch is triggered, we will receive 1 (when pressed) and 0 when released
    Coder.socketConnection.addListener("switch", function(data)
    {
        // we only want to change direction when we see 1
        if (parseInt(data.value) == 1)
            changeDirection(data);
        
    });
    
});